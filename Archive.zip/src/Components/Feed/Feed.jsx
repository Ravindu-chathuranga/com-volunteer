import React from 'react'
import './Feed.scss';

export default function Feed() {
  return (
    <div className='feed'>Feed</div>
  )
}
