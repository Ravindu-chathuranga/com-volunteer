import React from 'react'
import './Rightbar.scss'

export default function Rightbar() {
  return (
    <div className='rightbar'>Rightbar</div>
  )
}
