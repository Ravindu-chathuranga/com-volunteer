import React from 'react'
import './Sidebar.scss'

export default function Sidebar() {
  return (
    <div className='sidebar'>
      <div className="sidebarWrapper">
        <ul className="sidebarList">
          <li className="sidebarListItem">
            <div className='sidebarIcon'>
              <span className='sidebarListItemText'>Feed</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  )
}
